<?php
$pdo = new PDO("mysql:host=localhost;dbname=creator;charset=utf8mb4","root","");
?>